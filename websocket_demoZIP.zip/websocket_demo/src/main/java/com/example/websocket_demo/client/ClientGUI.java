package com.example.websocket_demo.client;

import java.util.concurrent.ExecutionException;

import javax.swing.JFrame;

import com.example.websocket_demo.Message;

public class ClientGUI extends JFrame {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        MyStompClient myStompClient = new MyStompClient("nisidh");
        myStompClient.sendMessage(new Message("nisidh", "Hello World!"));
        myStompClient.disconnect("nisidh");
    }


}
